<?php
	echo do_shortcode('[section type="services" items="' . $items . '" title="' . $title . '" description="' . $description . '" show_excerpt="' . $show_excerpt . '" excerpt_length="' . $excerpt_length . '" show_title="' . $show_title . '" show_detail_hover="' . $show_detail_hover . '" show_title_hover="' . $show_title_hover . '"]');
?>