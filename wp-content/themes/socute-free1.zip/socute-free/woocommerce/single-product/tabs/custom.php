<?php
/**
 * Custom tab
 */

echo yit_addp( $tab['custom_tab']["value"] );

?>