<?php

return array(
    'slug' => 'socute',
    'url' => 'https://yithemes.com/themes/wordpress/socute-multi-purpose-e-commerce-theme',

    //'price' => ''   // default price, if any response from remote
    //'img' => YIT_CORE_URL .'/assets/images/buy-premium.png'   // banner image
);
